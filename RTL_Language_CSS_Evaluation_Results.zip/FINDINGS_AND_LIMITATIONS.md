# Focused language-of-parts and CSS logical-properties static audit

## Dataset
- HTML documents: **480** (Urdu: 240, English: 240)
- Per model/language: 120 pages; prompt pairs: 40; 3 runs each.
- Audited raw HTML text and attributes, inline style attributes and embedded `<style>` CSS. External stylesheet contents and JS-injected text were not evaluated.

## Summary by model and language
```
  model language  pages  pages_lang_unmarked  pages_lang_strong_unmarked  total_latin_englishlike_candidates  high_confidence_englishlike_candidates  high_confidence_unmarked  unmarked_candidate_total  marked_candidate_total  pages_physical_css  pages_logical_css  physical_css_declarations  logical_css_declarations  all_css_declarations  stylesheets_external  html_parse_css_error_pages  physical_per100_css  logical_share_directional_pct
chatgpt  english    120                    0                           0                                   0                                       0                         0                         0                       0                  87                  1                        299                         1                 19986                    10                           0             1.496047                       0.333333
chatgpt     urdu    120                    0                           0                                   0                                       0                         0                         0                       0                  66                  0                        150                         0                 12867                    32                           0             1.165773                       0.000000
 claude  english    120                    0                           0                                   0                                       0                         0                         0                       0                  91                  5                        262                         7                 16297                     1                           0             1.607658                       2.602230
 claude     urdu    120                    0                           0                                   0                                       0                         0                         0                       0                  80                 20                        186                        36                 13385                    75                           0             1.389615                      16.216216
```

## Findings (Urdu pages)
- At least one high-confidence English-like phrase inheriting Urdu language: **0/240 pages**.
- At least one broader Latin-script phrase (including names/technical terms) inheriting Urdu language: **0/240 pages**.
- **0 high-confidence unmarked phrase instances**, **0 broad candidate instances**; **0 candidates** have an English language ancestor.
- CSS: **146/240 Urdu pages** contain at least one physical-side direction-sensitive declaration; **20/240** use at least one logical CSS property/value.
- Direction-sensitive declaration totals: **336 physical-side candidates**, **36 flow-relative logical declarations**, out of **26252 total declarations**.
- CSS source coverage: **107 Urdu HTML files reference external CSS** not captured in this static CSS audit.

## Representative high-confidence phrases (not verified WCAG violations)
(none)

## Representative CSS properties (not verified visual failures)
- P01 claude urdu: text-align | left
- P01 claude urdu: text-align | right
- P01 claude urdu: right | auto
- P01 claude urdu: left | 12px
- P01 claude urdu: text-align | left
- P01 claude urdu: text-align | left
- P01 claude urdu: text-align | right
- P01 claude urdu: text-align | right
- P02 claude urdu: text-align | left
- P02 claude urdu: text-align | right

## Interpretation limits
1. WCAG 2.2 **3.1.2 Language of Parts** exempts proper names, technical terms, indeterminate language and words naturalized into the surrounding language. Latin script != English. Candidate phrases must be judged with context before confirming violations. An explicitly marked `<span lang='en'>` may be correct, but script and language must both be checked.
2. Physical-side CSS (e.g. `margin-left`, `right`, `text-align: right`) is **not inherently wrong** in RTL. These are code-maintenance/layout-risk signals; no physical CSS declaration alone establishes a WCAG failure. Actual failures need browser-based RTL layout and task-specific expectations.
3. Asymmetric 4-value shorthands are only flagged when simple values are statically comparable; CSS functions and shorthand logical behavior are not fully resolved.
4. Text generated dynamically after load, pseudo-element content, and external CSS/JS need a live-browser follow-up. A baseline `lang='ur' dir='rtl'` is not evidence that all embedded English passages are correctly marked or that UI behavior is correct.
5. English-vs-Urdu groups conflate prompt language and output/UI locale, so causal claims about prompt language alone are not supported.

## Primary references
- W3C WCAG 2.2 SC 3.1.2 Understanding: https://www.w3.org/WAI/WCAG22/Understanding/language-of-parts
- W3C HTML H58 technique: https://www.w3.org/WAI/WCAG22/Techniques/html/H58
- MDN CSS logical properties: https://developer.mozilla.org/en-US/docs/Web/CSS/Guides/Logical_properties_and_values
