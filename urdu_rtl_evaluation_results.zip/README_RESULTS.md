# English/Urdu HTML Evaluation: reproducibility and interpretation

Input: prompt_set_40_v2.xlsx, urdu_rtl_study.zip.
Indexed: 480 HTML pages; evaluated: 480; expected full dataset: 480.

## Design
40 prompt pairs x 2 output languages x 2 models x 3 runs. English prompts request English output; Urdu prompts request Urdu output. Thus the 'language' contrast conflates prompt language and rendered locale/RTL behavior. It is NOT an isolated prompt-language causal effect.

## Generated outputs
- manifest.csv: page IDs, conditions, run labels, SHA-256 hashes. Two run numbers may be inferred from unnamed P21 files; see run_inferred.
- page_metrics.csv: static properties, browser results, axe WCAG A/AA findings, layout flags and structural evidence.
- structural_requirement_checks.csv and test_protocol.csv: rule-level structural presence screening; negative evidence requires human inspection; do NOT describe as full prompt-compliance rates.
- axe_violations.csv: rule ID, severity, number of affected nodes, one example target. The results only cover automatically tested rules and audited page state; no axe violation does NOT prove WCAG compliance.
- responsive_results.csv: per viewport document horizontal overflow and clipped-control flags. Data tables and other two-dimensional exceptions require manual judgment.
- interaction_probes.csv: only a small subset of widget types receive narrow probes; 'not_tested' is not a fail. There is no reliable all-40-page functional correctness rate from these generic checks.
- manual_review_queue.csv: follow-up review suggestions.
- balanced_manual_review_template.csv: run-1 stratified sample across all 40 prompts, models and languages for independent human review.
- paired_*.csv: within-model paired English/Urdu mean differences, bootstrapping whole prompt IDs, not treating 480 pages as independent prompts.
- figures/: charts. Avoid conflating node counts and unique rule violations.

## Manual evaluation still required
For representative/balanced samples and flagged pages: inspect semantic task completeness, Urdu wording quality, mixed Urdu+Latin number/email ordering, keyboard navigation, focus after opening/closing modals, functional workflows including P31 quiz scoring, P32 completion/deletion, P37 delete/cancel actions, P40 requirements without assuming live search, 320px reflow table exception, and dynamic UI states not present at page load. Record screenshots and two independent raters where feasible.

## Reproducibility
Pin and record browser and axe versions, test date, fonts, network behavior, JS exceptions and hash IDs. The experiment should load all pages from a local HTTP server and use consistent browser contexts/viewport settings. Pages may import external fonts/libraries. Network access can affect tests; log and if necessary rerun with explicit resource policy.

## Metrics
- structural_evidence_pct: proxy, NOT certified requirement completeness.
- axe_rule_count: count of distinct axe violation rules; axe_affected_nodes: sum of DOM nodes affected across rules (can count a node multiple times).
- unlabelled_controls_proxy: rough HTML label-name detector, NOT the browser-computed accessible name and NOT an axe violation by itself.
- html5_parse_diagnostics: html5lib parser diagnostics, NOT a Nu HTML Checker validation report.
- overflow_px and clipped_controls: screening flags, not by themselves WCAG nonconformity.
- urdu_letter_share: Unicode-script distribution, NOT linguistic quality or translation accuracy.
- per-prompt paired CI: exploratory; sample only 40 prompts; no claim of random representative task sampling.
- external_url_mentions: count of URL mentions in HTML source, not the number of network requests; offline/resource settings can affect measured layout and functionality.
- load_mode: local_http or set_content_fallback. Inline fallback does not give relative assets the same base origin as a local HTTP server.

Configuration snapshot:
```json
{
  "MAX_PAGES": null,
  "ENABLE_AXE": true,
  "ENABLE_INTERACTION_SMOKE": true,
  "VIEWPORTS": [
    320,
    390,
    768,
    1440
  ],
  "DEFAULT_VIEWPORT": 1440,
  "PAGE_TIMEOUT_MS": 12000,
  "SETTLE_MS": 200,
  "SAVE_SCREENSHOTS": false,
  "SCREENSHOT_LIMIT": 24,
  "ALLOW_EXTERNAL_RESOURCES": true,
  "FORCE_INLINE_HTML": false,
  "AXE_URL": "https://cdnjs.cloudflare.com/ajax/libs/axe-core/4.10.3/axe.min.js",
  "BOOTSTRAP_REPS": 3000,
  "SEED": 2027
}
```
